package Enums;

public enum TipoMaterial {

    LIBRO,
    EBOOK,
    REVISTA;

}
