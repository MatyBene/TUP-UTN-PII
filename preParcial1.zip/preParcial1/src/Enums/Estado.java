package Enums;

public enum Estado {

    PRESTADO,
    DISPONIBLE;

}
