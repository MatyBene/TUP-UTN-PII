package Enums;

public enum Genero {

    DRAMA,
    NOVELA,
    TERROR;

}
