package Interfaces;

public interface I_Prestable {

    void prestar();
    void devolver();

}
