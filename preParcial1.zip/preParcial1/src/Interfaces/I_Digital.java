package Interfaces;

public interface I_Digital {

    void leer();
    void resaltarTexto();
    void narrarParrafo();
    void cambiarFormato();
    void descargar();

}
