package Services;

import Models.Material;

import java.util.ArrayList;

public class BibliotecaService {

    private ArrayList<Material> catalogo;

    public BibliotecaService() {
        this.catalogo = new ArrayList<>(); // cuando creo la biblioteca se inicializa el array list
    }

    public void agregarMaterial(Material m){
        catalogo.add(m);
    }

    public String eliminarMaterial(String titulo){
        String msj = "El elemento a eliminar no se encontro en la lista.";

        for(Material m : catalogo){
            if(m.getTitulo().equalsIgnoreCase(titulo)){
                catalogo.remove(m);
                msj = "El elemento se encontro y se elimino correctamente.";
            }
        }

        return msj;
    }

}
