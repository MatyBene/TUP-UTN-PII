package guia3.e1.enums;

public enum TipoTransporte {
    AUTOBUS,
    TRANVIA,
    BICICLETA;
}
