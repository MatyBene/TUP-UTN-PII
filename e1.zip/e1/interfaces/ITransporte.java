package guia3.e1.interfaces;

public interface ITransporte {

    void arrancar();

    void detener();

    int obtenerCapacidad();

    void obtenerEstado();

}
