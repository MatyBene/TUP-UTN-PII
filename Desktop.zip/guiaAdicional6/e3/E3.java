package guiaAdicional6.e3;

import java.util.Scanner;

public class E3 {
    public static void ejecutar(Scanner input){

    }
}
