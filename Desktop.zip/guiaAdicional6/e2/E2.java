package guiaAdicional6.e2;

import java.util.Scanner;

public class E2 {
    public static void ejecutar(Scanner input){

    }
}
