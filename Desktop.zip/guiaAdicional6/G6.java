package guiaAdicional6;

import java.util.Scanner;

public class G6 {
    public static void ejecutar(Scanner input){

    }
}
