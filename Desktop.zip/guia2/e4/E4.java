package guia2.e4;

import java.util.Scanner;

public class E4 {
    public static void ejecutar(Scanner input){

    }
}
