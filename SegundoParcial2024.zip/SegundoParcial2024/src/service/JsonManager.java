package service;

import model.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonManager {

    public static StarWarsRegistro<Personaje> mapeoPelicula(){
        StarWarsRegistro<Personaje> personajes = new StarWarsRegistro<>();

        try{
            // Personajes del JSON
            JSONObject json = new JSONObject(JsonUtils.leer("personajes.json"));

            // Array de personajes
            JSONArray jPersonajes = json.getJSONArray("personajes");

            for(int i = 0; i < jPersonajes.length(); i++){
                // Personaje
                Personaje personaje = new Personaje();

                // Personaje JSON
                JSONObject jPersonaje = jPersonajes.getJSONObject(i);

                // Maestro JSON
                JSONObject jMaestro = jPersonaje.getJSONObject("maestro");

                // Habilidades JSON
                JSONArray jHabilidades = jMaestro.getJSONArray("habilidades");

                // Habilidades
                List<String> habilidades = new ArrayList<>();
                for(int ii = 0; ii < jHabilidades.length(); ii++){
                    habilidades.add(jHabilidades.getString(ii));
                }

                // Maestro
                Maestro maestro = new Maestro();
                maestro.setNombre(jMaestro.getString("nombre"));
                maestro.setEs_jedi(jMaestro.getBoolean("es_jedi"));
                maestro.setHabilidades(habilidades);

                // Amigos JSON
                JSONArray jAmigos = jPersonaje.getJSONArray("amigos");

                // Amigos
                List<Amigo> amigos = new ArrayList<>();
                for(int iii = 0; iii < jAmigos.length(); iii++){
                    JSONObject jAmigo = jAmigos.getJSONObject(iii);

                    Amigo amigo = new Amigo();
                    amigo.setNombre(jAmigo.getString("nombre"));
                    amigo.setPiloto(jAmigo.getBoolean("piloto"));

                    Nave nave = new Nave();
                    if(jAmigo.isNull("nave")){
                        amigo.setNave(null);
                    } else {
                        JSONObject jNave = jAmigo.getJSONObject("nave");

                        nave.setNombre(jNave.getString("nombre"));
                        nave.setModelo(jNave.getString("modelo"));

                        amigo.setNave(nave);
                    }

                    amigos.add(amigo);
                }

                // Eventos JSON
                JSONArray jEventos = jPersonaje.getJSONArray("eventos");

                List<Evento> eventos = new ArrayList<>();
                for(int iv = 0; iv < jEventos.length(); iv++){
                    JSONObject jEvento = jEventos.getJSONObject(iv);

                    Evento evento = new Evento();
                    evento.setNombre(jEvento.getString("nombre"));
                    evento.setAnio(jEvento.getInt("anio"));
                    evento.setGanada(jEvento.getBoolean("ganada"));

                    eventos.add(evento);
                }

                // Agrego atributos personaje
                personaje.setNombre(jPersonaje.getString("nombre"));
                personaje.setEdad(jPersonaje.getInt("edad"));
                personaje.setJedi(jPersonaje.getBoolean("jedi"));
                personaje.setPlaneta_nacimiento(jPersonaje.getString("planeta_nacimiento"));
                personaje.setMaestro(maestro);
                personaje.setAmigos(amigos);
                personaje.setEventos(eventos);

                personajes.agregarPersonaje(personaje);
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        return personajes;
    }


}
